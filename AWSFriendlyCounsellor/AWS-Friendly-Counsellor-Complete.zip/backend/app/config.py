REGIONAL_COST_MULTIPLIER = {
    "us-east-1": 1.0,
    "eu-west-1": 1.2,
    "ap-southeast-1": 1.5,
}
