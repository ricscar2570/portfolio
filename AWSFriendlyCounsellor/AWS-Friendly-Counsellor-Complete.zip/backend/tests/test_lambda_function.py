def test_lambda_function():
    assert True
