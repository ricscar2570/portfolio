MARKETPLACE_LINKS = {
    "EC2": "https://aws.amazon.com/marketplace/pp/prodview-ec2",
    "S3": "https://aws.amazon.com/marketplace/pp/prodview-s3",
    "DynamoDB": "https://aws.amazon.com/marketplace/pp/prodview-dynamodb",
}
