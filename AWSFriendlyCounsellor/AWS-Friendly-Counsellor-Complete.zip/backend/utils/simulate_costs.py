def simulate_cost(region, base_cost, multiplier=1.0):
    return base_cost * multiplier
