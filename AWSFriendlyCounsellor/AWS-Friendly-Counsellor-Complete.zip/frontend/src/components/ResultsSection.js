function ResultsSection({ results }) {
  return <div>{JSON.stringify(results)}</div>;
}
export default ResultsSection;
