export function generatePDF(data) {
  console.log('Generating PDF with data:', data);
}
