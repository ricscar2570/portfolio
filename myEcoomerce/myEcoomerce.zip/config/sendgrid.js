// SendGrid configuration file
module.exports = {};