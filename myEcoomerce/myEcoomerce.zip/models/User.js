// User schema definition
const mongoose = require('mongoose'); module.exports = mongoose.model('User', {});